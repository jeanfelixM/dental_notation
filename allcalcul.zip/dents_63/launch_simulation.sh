cd input/dents_63_002_to_dents_63_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_63_003_to_dents_63_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_63_008_to_dents_63_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_63_006_to_dents_63_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_63_004_to_dents_63_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_63_010_to_dents_63_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_63_011_to_dents_63_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

