cd input/dents_67_002_to_dents_67_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_67_003_to_dents_67_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_67_004_to_dents_67_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_67_005_to_dents_67_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_67_006_to_dents_67_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_67_007_to_dents_67_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_67_008_to_dents_67_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_67_009_to_dents_67_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_67_010_to_dents_67_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_67_011_to_dents_67_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/dents_67_012_to_dents_67_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

