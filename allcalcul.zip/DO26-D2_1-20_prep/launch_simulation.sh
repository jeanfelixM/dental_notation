cd input/DO26-D2_1-20_prep_011_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_012_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_003_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_004_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_020_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_002_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_015_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_018_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_009_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_010_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_016_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_019_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_014_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_005_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_006_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_008_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_017_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

cd ../../input/DO26-D2_1-20_prep_013_to_DO26-D2_1-20_prep_001
chmod 770 launch_simulation.sh
./launch_simulation.sh

