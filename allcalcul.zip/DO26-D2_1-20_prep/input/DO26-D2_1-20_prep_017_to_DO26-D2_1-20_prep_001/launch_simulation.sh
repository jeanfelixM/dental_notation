deformetrica estimate model.xml data_set.xml -p ../../optimization_parameters.xml --output=output > logout.txt

